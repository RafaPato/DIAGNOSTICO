from flask import Flask, request, jsonify
import joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier

app = Flask(__name__)

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.json
        prediction = model.predict([data])
        disease_name = get_disease_name(prediction[0])
        return jsonify({'disease_name': disease_name})
    except Exception as e:
        return jsonify({'error': str(e)})
def get_disease_name(diagnosis_code):
    disease_mapping = {
        1: 'Inflamacao grave',
        2: 'Anemia',
        3: 'Pancreatite',
        4: 'Hipoplasia mieloide',
        5: 'Hipercolesterolemia',
        6: 'Lesão hepatica',
        7: 'DRC',
        8: 'Desidratacao',
        9: 'Infeccao parasitaria',
        10: 'Infeccao bacteriana',
        11: 'Infeccao Viral',
        12: 'DRC e Cardiopatia',
        13: 'Neoplasia hepatica',
        14: 'Anemia hemolitica',
        15: 'Diabetes',
        16: 'Pre-diabetes',
        17: 'Anemia e Infeccao',
        18: 'Hepatopata',
        19: 'Trombocitopenia e Inflamacao',
    }
    return disease_mapping.get(diagnosis_code, 'Unknown Disease')
if __name__ == '__main__':

    dataset = pd.read_csv('dataset-hemograma.csv')
    
    features = dataset.drop('diagnosis', axis=1)
    labels = dataset['diagnosis']
    
    X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=0.2, random_state=42)
    
    model = RandomForestClassifier()
    model.fit(X_train, y_train)
    
    joblib.dump(model, 'model.joblib')

    app.run(debug=True)